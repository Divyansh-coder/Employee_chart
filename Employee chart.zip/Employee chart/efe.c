#include<stdio.h>
#include<stdlib.h>
main()
{
	int i;
	system("COLOR 1");
	printf("\n\n\n\t-------------------------------------------------\n\n");
	printf("\t\t\tEmployee Window\n\n");
	printf("\t\t1. Enter details of New employee.\n");
	printf("\t\t2. View Employee chart.\n");
	printf("\t\t3. Exit.\n\n");
	printf("\t-------------------------------------------------\n\n");
	scanf("%d",&i);
	switch(i)
	{
		case 1:
			system("cls");
			enter_details();
		case 2:
			system("cls");
			view();
		case 3:
			system("cls");
			exit(0);
		default:
			printf("ERROR_NOT_VALID_INDEX");
			system("cls");
			main();
	}
	return 0;
}
enter_details()
{
	FILE *fp;
	char another;
	struct employee
	{
		char name[1000];
		int a;
		long long s,pn;
	};
	struct employee e;
	fp=fopen("employee.txt","a");
	do
	{
		printf("\nEnter Name: ");
		scanf(" %[^\n]s",e.name);
		printf("\nEnter Age: ");
		scanf("%d",&e.a);
		printf("\nEnter Phone number: ");
		scanf("%lld",&e.pn);
		printf("\nEnter Salary: ");
		scanf("%lld",&e.s);
 		fprintf ( fp, "%s\t%d\t%lld\t\t%lld\n", e.name, e.a, e.pn, e.s ) ; 
		printf("\nDo you want to enter new employee details (y/n)\n");
		fflush(stdin);
		another=getche();
	}while(another=='y');
	fclose(fp);
	if (another=='n')
	{
		system("cls");
		main();
	}
}
view()
{
	printf("\n\n\t********************              ********************\n\t********************EMPLOYEE CHART********************\n\t********************              ********************\n");
	printf("\tName\t\tAge\tPhone Number\t\tSalary\n");
	FILE *op;
	char s[1000];
	int i;
	op=fopen("employee.txt","r");
	while ( fgets ( s, 999, op ) != NULL )
 		printf ( "\t%s" , s ) ;
 	fclose(op);
 	printf("\n--------------------------------------------------------");
 	printf("\nFor main menu press \"m\"\n");
 	fflush(stdin);
 	i=getche();
 	if (i=='m')
 	{
 		system("cls");
 		main();
 	}
}
